@extends('admin.layout.app')
@section('content')

<div class="container">



    <div class="card mt-2">
        <div class="card-header">
                Move Print
        </div>
        <div class="card-body">
            <form action="{{action('PrintController@movie_print_view')}}" method="get">

                <div class="row">
                    <div class="col-3">
                        <div class="form-group">
                            <label for="">Start</label>
                            <input type="text" name="start" id="" class="form-control" placeholder="" aria-describedby="helpId">
                            <small id="helpId" class="text-muted"></small>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="">End</label>
                            <input type="text" name="end" id="" class="form-control" placeholder="" aria-describedby="helpId">
                            <small id="helpId" class="text-muted"></small>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="">Type</label>
                            <select name="type" id="" class="form-control">
                                <option value="4">4 Photo</option>
                                <option value="9">9 Photo</option>
                                <option value="16">16 Photo</option>
                            </select>
                            <small id="helpId" class="text-muted"></small>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="">.</label>
                            <input type="submit" name="" id="" class="form-control btn btn-primary btnprn" value="Print Now" placeholder="" aria-describedby="helpId">
                            <small id="helpId" class="text-muted"></small>
                        </div>
                    </div>
                </div>
            </form>

        </div>
        <div class="card-footer text-muted">
           
        </div>
    </div>

</div>


@endsection
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card mt-2">
        <div class="card-header">
            Header
        </div>
        <div class="card-body">
            <input id="myInput" class="form-control mb-3" type="text" placeholder="Search..">

            <script>
            $(document).ready(function() {
                $("#myInput").on("keyup", function() {
                    var value = $(this).val().toLowerCase();
                    $("#myDIV tr").filter(function() {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });
            </script>
            <table class="table table-striped table-bordered table-sm">
                <thead>
                    <tr>
                        <th>KT ID</th>
                        <th>Name</th>
                        <th>Year</th>
                        <th>Country</th>
                        <th>Genre</th>
                        <th>Actors</th>
                        <th>Director</th>
                        <th>Count</th>
                        <th>More</th>
                    </tr>
                </thead>
                <tbody id="myDIV">
                    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($movie->ktid); ?></td>
                        <td><?php echo e($movie->title); ?></td>
                        <td><?php echo e($movie->year); ?></td>
                        <td><?php echo e($movie->country); ?></td>
                        <td><?php echo e($movie->genre); ?></td>
                        <td><?php echo e($movie->actors); ?></td>
                        <td><?php echo e($movie->director); ?></td>
                        <td><?php echo e($movie->count); ?></td>
                        <td>
                            <a href="<?php echo e(action('Admin\AdminController@movie_view',$movie->id)); ?>" class="text-primary"><i
                                    class="far fa-eye"></i> View</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer text-muted">
            Footer
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\khitthit\resources\views/admin/admin.blade.php ENDPATH**/ ?>
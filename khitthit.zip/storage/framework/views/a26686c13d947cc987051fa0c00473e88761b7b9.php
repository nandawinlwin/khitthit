<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    

        <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-md-3 pt-2">
            <a href="<?php echo e(action('FrontendController@view',$movie->id)); ?>" style="text-decoration: none;color:black;">
                <div class="card">
                    <img class="card-img-top img-fluid" style="height:300px;"  src="<?php echo e($movie->poster); ?>" alt="Card image" style="width:100%">
                    <div class="p-2">
                        <?php if($movie->type == 'series'): ?>
                        <?php if($movie->country == 'USA'): ?>
                        <span class="pull-left">E-<?php echo e($movie->ktid); ?> </span> <span class="pull-right"><i
                                class="fa fa-star"></i> <?php echo e($movie->imdbrating); ?> <br></span>
                        <?php endif; ?>
                        <?php else: ?>
                        <span class="pull-left"><?php echo e($movie->ktid); ?>  </span> <span class="pull-right"><i
                                class="fa fa-star"></i> <?php echo e($movie->imdbrating); ?> <br></span>
                        <?php endif; ?>

                        <span class='clearfix'></span>
                        <span><?php echo e($movie->title); ?></span> <br>
                        <span><?php echo e($movie->year); ?></span>

                        <?php if($movie->type == 'series'): ?>
                        <span class="float-right"><?php echo e($movie->type); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </a>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <hr>
    <span class="mt-2"><?php echo e($movies->links()); ?></span>
</div>



<!-- Modal -->
<form method="POST" action="<?php echo e(route('login')); ?>">
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Login')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <?php echo csrf_field(); ?>

                    <div class="form-group row">
                        <label for="email"
                            class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                        <div class="col-md-6">
                            <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                        <div class="col-md-6">
                            <input id="password" type="password"
                                class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required
                                autocomplete="current-password">

                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-6 offset-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                    <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                <label class="form-check-label" for="remember">
                                    <?php echo e(__('Remember Me')); ?>

                                </label>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <?php if(Route::has('password.request')): ?>
                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                            <?php echo e(__('Forgot Your Password?')); ?>

                        </a>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-primary">
                            <?php echo e(__('Login')); ?>

                        </button>


                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

</form>
<?php if(auth()->guard()->guest()): ?>
<script>
$('#exampleModal').modal({
    show: true
})
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\khitthit\resources\views/welcome.blade.php ENDPATH**/ ?>
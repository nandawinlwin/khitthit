<?php $__env->startSection('content'); ?>

<script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/datatable/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.printPage.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.table2excel.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.table2excel.min.js')); ?>"></script>
<div class="container">



    <div class="card mt-2">
        <div class="card-header">
            <input type="text" name="" class="form-control" id="">
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered table-sm">
                <thead class="thead-inverse">
                    <tr>
                        <th>KT ID</th>
                        <th>Movie Title</th>
                        <th style="width:70px;">More</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($movie->type == 'series'): ?>
                    <tr>
                        <td scope="row"><?php echo e($movie->ktid); ?></td>
                        <td><?php echo e($movie->title); ?></td>
                        <td>
                            <a href="<?php echo e(action('PrintController@series_print_view',$movie->id)); ?>" class="btnprn"><i
                                    class="fas fa-file-powerpoint "></i> View</a>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer text-muted">

        </div>
    </div>

</div>

<script type="text/javascript">
$(document).ready(function() {
    $('.btnprn').printPage();
});
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\khitthit\resources\views/admin/print/series_print.blade.php ENDPATH**/ ?>
<div class="">
    <nav class="navbar navbar-expand-sm bg-light navbar-light">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/admin')); ?>">
                <i class="fas fa-home"></i> HOME
            </a>
            <ul class="navbar-nav">
                <!-- Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                        <i class="fa fa-film"></i> Movie
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="<?php echo e(url('/movie/create')); ?>"><i class="fas fa-plus-square"></i> New</a>
                        <a class="dropdown-item" href="<?php echo e(url('/all_movie')); ?>"><i class="fas fa-th-list"></i> All Movie</a>
                    </div>
                </li>

                <!-- Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                        <i class="fas fa-layer-group"></i> Series
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="<?php echo e(url('/series/create')); ?>"><i class="fas fa-plus-square"></i> New</a>
                        <a class="dropdown-item" href="<?php echo e(url('/all_series')); ?>"><i class="fas fa-th-list"></i> All Series</a>
                    </div>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/users')); ?>"><i class="fas fa-users"></i> Users</a>
                </li>

                <!-- Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                        <i class="fas fa-print"></i> Print
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="<?php echo e(url('/print/movie')); ?>"><i class="fas fa-file-video"></i> Movie Print</a>
                        <a class="dropdown-item" href="<?php echo e(url('print/series')); ?>"><i class="fas fa-object-ungroup"></i> Series Print</a>
                    </div>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/setting')); ?>"><i class="fas fa-cogs"></i> Setting</a>
                </li>



            </ul>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav mr-auto">

                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ml-auto">
                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><i class="fas fa-sign-in-alt"></i> <?php echo e(__('Login')); ?></a>
                    </li>
                    <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('register')); ?>"><i class="fas fa-registered"></i> <?php echo e(__('Register')); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <i class="fas fa-user"></i> <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <i class="fas fa-sign-out-alt"></i> <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
</div><?php /**PATH E:\project\khitthit\resources\views/admin/layout/nav.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card">
        <div class="card-header">
            <h3 class="pull-left"> <?php echo e($movie->title); ?> </h3>
            <span>
                <?php if($yes == 1 ): ?>
                <span class="pull-right">
                    <a href="<?php echo e(action('HomeController@removewatchlist',$movie->id)); ?>"><i class="fa fa-trash"
                            style="font-size:40px"></i></a>
                </span>
                <?php else: ?>
                <span class="pull-right">
                    <a href="<?php echo e(action('HomeController@addwatchlist',$movie->id)); ?>"><i class="fa fa-bookmark"
                            style="font-size:40px"></i></a>
                </span>
                <?php endif; ?>
            </span>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-3 pt-2">
                    <img src="<?php echo e($movie->poster); ?>"
                        class="img-fluid ${3|rounded-top,rounded-right,rounded-bottom,rounded-left,rounded-circle,|}"
                        alt="">
                </div>

                <div class="col-12 col-md-3 pt-3">
                    <h4>ID - <?php echo e($movie->ktid); ?></h4>
                    <hr>
                    Name - <?php echo e($movie->title); ?>

                    <hr>
                    Year - <?php echo e($movie->year); ?>

                    <hr>
                    Country - <?php echo e($movie->country); ?>

                    <hr>
                    Runtime - <?php echo e($movie->runtime); ?>

                    <hr>
                    Rating - <?php echo e($movie->imdbrating); ?>

                    <hr>
                </div>

                <div class="col-12 col-md-6">
                    Actors - <?php echo e($movie->actors); ?>

                    <hr>
                    Genre - <?php echo e($movie->genre); ?>

                    <hr>
                    Director - <?php echo e($movie->director); ?>

                    <hr>
                    <div class="card mt-3">
                        <div class="card-body">
                            AD
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="card mt-3">
                        <div class="card-body">
                            <h4>Plot</h4>
                            &nbsp&nbsp&nbsp&nbsp&nbsp<?php echo e($movie->plot); ?>

                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="card-footer text-muted">
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\khitthit\resources\views/view.blade.php ENDPATH**/ ?>
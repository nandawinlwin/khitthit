<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class watchlist extends Model
{
    //
}
